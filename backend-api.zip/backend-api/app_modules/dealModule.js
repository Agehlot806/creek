let deal ={};

async function getAllDealData(){
    try {
        let squery ="SELECT id,deal_title title,deal_description `desc`,deal_logo logo,deal_cover cover FROM ck_deals WHERE  `status` = '3'";
        let row =   await sqlcache(squery,[]);
        if(row.length > 0){
            for(let i =0; i<row.length; i++){
                row[i]['raised_percentage'] = 40;
                row[i]['amount_per_subscriber'] = 1660;
                row[i]['number_of_subscriber'] = 200;
            }
        }
        return row;
    } catch (error) {
        throw error;
    }
}

async function getAllBestDealData(){
    try {
        let squery ="SELECT id,deal_title title,deal_description `desc`,deal_logo logo,deal_cover cover FROM ck_deals WHERE  `status` = '3'";
        let row =   await sqlcache(squery,[]);
        if(row.length > 0){
            for(let i =0; i<row.length; i++){
                row[i]['raised_percentage'] = 40;
                row[i]['amount_per_subscriber'] = 1660;
                row[i]['number_of_subscriber'] = 200;
            }
        }   
        return row;
    } catch (error) {
        throw error;
    }
}


async function getSingleDealData(dealId){
    try {
        let squery ="SELECT id, deal_title title,deal_description `desc`,deal_logo logo,deal_cover cover FROM ck_deals WHERE  `status` = '3' AND id =?";
        let row =   await sqlcache(squery,[dealId]);
       // console.log(squery)
       if(row.length > 0){
        row[0]['raised_percentage'] = 40;
        row[0]['amount_per_subscriber'] = 1660;
        row[0]['number_of_subscriber'] = 200;
         row[0]['pitch'] = await getSinglePitchDoc(dealId);
         row[0]['video'] = await getSingleDealVideo(dealId);
         row[0]['faq'] =   await getDealFaq(dealId);
         row[0]['updates'] =   await getDealUpdates(dealId);
         row[0]['term'] =   await getSingleDealTerm(dealId);
       }
       
        return row;
    } catch (error) {
        throw error;
    }
}

async function getSingleDealTerm(dealId){
    try {

            let squery ="SELECT minimum_investment,target,end_date,legal_name,founded,form,no_of_employees,website,facebook,linkedin,instagram,headquarters FROM `ck_deal_terms`  WHERE  `deal_id` = ? AND status=1";
            let row =   await query(squery,[dealId]);
            if(row.length >0){
          
              return row;
            }
        
        return '';
    } catch (error) {
        throw error;
    }
}

async function getDealUpdates(dealId){
    try {
       // let checkDeal = checkDealId(dealId,userId);
        //if (checkDeal) {
            let squery ="SELECT * FROM `ck_deal_updates` WHERE  `deal_id` = ? AND status=1";
            let row =   await query(squery,[dealId]);
            if(row.length >0){
            return row;
            }
        //}
        return '';
    } catch (error) {
        throw error;
    }
}

async function getSingleDealVideo(dealId){
    try {
      
            let squery ="SELECT * FROM `ck_deal_videos` WHERE  `deal_id` = ? AND status=1";
            let row =   await query(squery,[dealId]);
            if(row.length >0){
                return row;
            }
    
        return '';
    } catch (error) {
        throw error;
    }
}

async function getDealFaq(dealId){
    try {
        //let checkDeal = checkDealId(dealId,userId);
        //if (checkDeal) {
            let squery ="SELECT * FROM `ck_deal_faqs` WHERE  `deal_id` = ? AND status=1";
            let row =   await query(squery,[dealId]);
            if(row.length >0){
            return row;
            }
        //}
        return '';
    } catch (error) {
        throw error;
    }
}
async function getSinglePitchDoc(dealId){
    try {
        //let checkDeal = checkDealId(dealId,userId);
        //if (checkDeal) {
            let squery ="SELECT * FROM `ck_deal_pitch` WHERE  `deal_id` = ?";
            let row =   await query(squery,[dealId]);
            if(row.length >0){
            return row;
            }
       // }
        return '';
    } catch (error) {
        throw error;
    }
}

async function insertRaiseCapital(userId, founder_name,founder_official_number,
    company_email,founders_linkedin_url,
    registered_comapny_name,company_linkedin_page,
    website,previous_fundraising_rounds,
    describe_your_product,describe_the_traction_status,
    describe_the_traction,revenue_company_making_status,
    revenue_company_making,no_of_employees,
    raise_a_deal_round,private_round,existing_commitments,pitch){
    try {
        let squery ="INSERT INTO ck_deals (user_id,deal_description,created_at,updated_at) VALUES (?,?,?,?)";
        let describe_your_products ='';
        if(describe_your_product !='' && describe_your_product !=null){
            describe_your_products =Buffer.from(describe_your_product).toString('base64');
        }
       
     //  console.log(Buffer.from("SGVsbG8gV29ybGQ=", 'base64').toString('ascii'));
     //npm install --save express multer
       let row =   await query(squery,[userId,describe_your_products,new Date(),new Date()]);
       // console.log(row)
       // return describe_your_products;
        if(row['insertId']){
            let lastDealId = row.insertId;
            let squery ="INSERT INTO ck_deal_people (deal_id,founder_name,founder_official_number,created_at,updated_at) VALUES (?,?,?,?,?)";
      
            let row_deal_people =   await query(squery,[lastDealId,founder_name,founder_official_number,new Date(),new Date()]);
            if(row_deal_people['insertId']){
               // return row_deal_people;
               let squery =`INSERT INTO ck_deal_terms (deal_id,legal_name,linkedin,
                website,previous_fundraising_rounds,describe_the_traction_status,
                describe_the_traction,revenue_company_making_status,revenue_company_making,no_of_employees,
                raise_a_deal_round,existing_commitments,private_round,created_at,updated_at) 
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;
                
                let row_deal_terms =   await query(squery,
                    [lastDealId,registered_comapny_name,
                        company_linkedin_page,
                        website,
                        previous_fundraising_rounds,
                        describe_the_traction_status,
                        describe_the_traction,
                        revenue_company_making_status,
                        revenue_company_making,
                        no_of_employees,
                        raise_a_deal_round,
                        existing_commitments,
                        private_round,
                    new Date(),new Date()]);
                if(row_deal_terms['insertId']){
                    let squery =`INSERT INTO ck_deal_pitch (deal_id,pitch_document,created_at,updated_at) 
                        VALUES (?,?,?,?)`;
                        
                        let row_deal_pitch =   await query(squery,
                            [lastDealId,pitch,
                            new Date(),new Date()]);
                        if(row_deal_pitch['insertId']){
                            return row_deal_pitch;
                        }else{
                            return false;
                        }
                }else{
                    return false;
                }
            }else{
                return false;
            }
            
           // return Buffer.from("ZGVzY3JpYmVfeW91cl9wcm9kdWN0", 'base64').toString('ascii');
        }else{
            return false;
        }
    } catch (error) {
        throw error;
    }
}


async function updatePitchDoc(dealId,pitch){
    try {
        let squery ="SELECT * FROM `ck_deal_pitch` WHERE  `deal_id` = ?";
        let row =   await query(squery,[dealId]);
        if(row.length >0){
           // return row[0];
           let squery ="UPDATE ck_deal_pitch  SET pitch_document = ? ,updated_at = ?  WHERE deal_id = ?";
           let row = await query(squery,[pitch, new Date(),dealId]);
          //console.log(squery);
            if(row['affectedRows']){
                return true;
            }
        }
        return false;
    } catch (error) {
        throw error;
    }
}

async function getPitchDoc(dealId,userId){
    try {
        let checkDeal = checkDealId(dealId,userId);
        if (checkDeal) {
            let squery ="SELECT * FROM `ck_deal_pitch` WHERE  `deal_id` = ?";
            let row =   await query(squery,[dealId]);
            if(row.length >0){
            return row[0];
            }
        }
        return false;
    } catch (error) {
        throw error;
    }
}

async function checkDealId(dealId,userId){
    try {
        let squery ="SELECT * FROM `ck_deals` WHERE  `id` = ? AND user_id= ?";
        let row =   await query(squery,[dealId,userId]);
        if(row.length >0){
           return true;
        }
        return false;
    } catch (error) {
        throw error;
    }
}

async function getBasicInfo(dealId,userId){
    try {
            let squery ="SELECT deal_title,deal_description,deal_logo,deal_cover,deal_short_description FROM `ck_deals` WHERE  `id` = ? AND user_id = ?";
            let row =   await query(squery,[dealId,userId]);
            
            if(row.length >0){
                //console.log(row[0])
             if(row[0]['deal_short_description'] != null && row[0]['deal_short_description'] !='')
                row[0]['deal_short_description'] = Buffer.from(row[0]['deal_short_description'], 'base64').toString('ascii');
             if(row[0]['deal_description'] != null && row[0]['deal_description'] !='')
                row[0]['deal_description'] = Buffer.from(row[0]['deal_description'], 'base64').toString('ascii');
               
                return row[0];
            }
        
        return false;
    } catch (error) {
        throw error;
    }
}


async function updateBasicInfo(dealId,userId,deal_title,deal_description,deal_logo,deal_cover,deal_short_description,video_link){
    try {
        let squery ="SELECT id FROM `ck_deals` WHERE  `id` = ? AND user_id =?";
        let row =   await query(squery,[dealId,userId]);
        if(row.length >0){
         //  return Buffer.from(deal_description).toString('base64');
          let deal_descriptions ='';
              if(deal_description !='' && deal_description !=null){
               deal_descriptions =Buffer.from(deal_description).toString('base64');
              }
   
            //  let deal_short_descriptions ='';
              if(deal_short_description !='' && deal_short_description !=null){
                deal_short_descriptions =Buffer.from(deal_short_description).toString('base64');
              }
           
           let squery ="UPDATE ck_deals  SET deal_title =?,deal_description = ?,deal_logo = ?,deal_cover = ?,deal_short_description = ?,video_link=?  WHERE id = ?";
           let row = await query(squery,[deal_title,deal_descriptions,deal_logo,deal_cover,deal_short_descriptions,video_link,dealId]);
          //console.log(squery);
            if(row['affectedRows']){
                return true;
            }
        }
        return false;
    } catch (error) {
        throw error;
    }
}


async function insertUpdateTab(dealId,title,description){
    try {
        let squery ="INSERT INTO ck_deal_updates (deal_id,title,description,created_at,updated_at) VALUES (?,?,?,?,?)";
        let row = await query(squery,[dealId,title,description,new Date(),new Date()]);
        if(row['insertId']){
            return true;
        }else{
            return false;
        }
    } catch (error) {
        throw error;
    }
}

async function getUpdatesTab(dealId,userId){
    try {
        let checkDeal = checkDealId(dealId,userId);
        if (checkDeal) {
            let squery ="SELECT * FROM `ck_deal_updates` WHERE  `deal_id` = ? AND status=1";
            let row =   await query(squery,[dealId]);
            if(row.length >0){
            return row;
            }
        }
        return false;
    } catch (error) {
        throw error;
    }
}

async function deleteUpdatesTab(uTabId,dealId,userId){
    try {
        let checkDeal = checkDealId(dealId,userId);
        if (checkDeal) {
            let squery ="UPDATE ck_deal_updates  SET status =?  WHERE id = ? AND deal_id = ?";
           let row = await query(squery,[0,uTabId,dealId]);
          //console.log(squery);
            if(row['affectedRows']){
                return true;
            }
        }
        return false;
    } catch (error) {
        throw error;
    }
}

//FAQ 
async function insertFaqTab(dealId,question,answer){
    try {
        let squery ="INSERT INTO ck_deal_faqs (deal_id,question,answer,created_at,updated_at) VALUES (?,?,?,?,?)";
        let row = await query(squery,[dealId,question,answer,new Date(),new Date()]);
        if(row['insertId']){
            return true;
        }else{
            return false;
        }
    } catch (error) {
        throw error;
    }
}

async function getFaqTab(dealId,userId){
    try {
        let checkDeal = checkDealId(dealId,userId);
        if (checkDeal) {
            let squery ="SELECT * FROM `ck_deal_faqs` WHERE  `deal_id` = ? AND status=1";
            let row =   await query(squery,[dealId]);
            if(row.length >0){
            return row;
            }
        }
        return false;
    } catch (error) {
        throw error;
    }
}

async function deleteFaqTab(fTabId,dealId,userId){
    try {
        let checkDeal = checkDealId(dealId,userId);
        if (checkDeal) {
            let squery ="UPDATE ck_deal_faqs  SET status =?  WHERE id = ? AND deal_id = ?";
           let row = await query(squery,[0,fTabId,dealId]);
          //console.log(squery);
            if(row['affectedRows']){
                return true;
            }
        }
        return false;
    } catch (error) {
        throw error;
    }
}

//FAQ


//Video
async function insertVideoTab(dealId,video_link){
    try {
        let squery ="INSERT INTO ck_deal_videos (deal_id,video_link,created_at,updated_at) VALUES (?,?,?,?)";
        let row = await query(squery,[dealId,video_link,new Date(),new Date()]);
        if(row['insertId']){
            return true;
        }else{
            return false;
        }
    } catch (error) {
        throw error;
    }
}

async function getVideoTab(dealId,userId){
    try {
        let checkDeal = checkDealId(dealId,userId);
        if (checkDeal) {
            let squery ="SELECT * FROM `ck_deal_videos` WHERE  `deal_id` = ? AND status=1";
            let row =   await query(squery,[dealId]);
            if(row.length >0){
            return row;
            }
        }
        return false;
    } catch (error) {
        throw error;
    }
}

async function deleteVideoTab(fTabId,dealId,userId){
    try {
        let checkDeal = checkDealId(dealId,userId);
        if (checkDeal) {
            let squery ="UPDATE ck_deal_videos  SET status =?  WHERE id = ? AND deal_id = ?";
           let row = await query(squery,[0,fTabId,dealId]);
          //console.log(squery);
            if(row['affectedRows']){
                return true;
            }
        }
        return false;
    } catch (error) {
        throw error;
    }
}

async function getTerm(dealId,userId){
    try {
        let checkDeal = checkDealId(dealId,userId);
        if (checkDeal) {
            let squery ="SELECT * FROM `ck_deal_terms`  WHERE  `deal_id` = ? AND status=1";
            let row =   await query(squery,[dealId]);
            if(row.length >0){
                let termCert = await getTermComapnyCert(dealId,userId);
                let dueDilligence = await getCompanyDueDilligence(dealId,userId);
                let otherdoc = await getOtherDoc(dealId,userId);
                if(termCert){
                    row[0]['company_cert'] = termCert;
                }else{
                    row[0]['company_cert'] = '';
                }
                if(dueDilligence){
                    row[0]['company_due_dilligence'] = dueDilligence;
                }else{
                    row[0]['company_due_dilligence'] = '';
                }
                if(otherdoc){
                    row[0]['other_doc'] = otherdoc;
                }else{
                    row[0]['other_doc'] = '';
                }
              return row[0];
            }
        }
        return false;
    } catch (error) {
        throw error;
    }
}

async function getTermComapnyCert(dealId,userId){
    try {
        let checkDeal = checkDealId(dealId,userId);
        if (checkDeal) {
            let squery ="SELECT * FROM `ck_deal_documents`  WHERE  `deal_id` = ? AND status=1 AND document_type='deal_term' AND document_sub_type='company_certificate'";
            let row =   await query(squery,[dealId]);
            if(row.length >0){
              return row;
            }
        }
        return false;
    } catch (error) {
        throw error;
    }
}

async function getCompanyDueDilligence(dealId,userId){
    try {
        let checkDeal = checkDealId(dealId,userId);
        if (checkDeal) {
            let squery ="SELECT * FROM `ck_deal_documents`  WHERE  `deal_id` = ? AND status=1 AND document_type='deal_term' AND document_sub_type='company_due_dilligence'";
            let row =   await query(squery,[dealId]);
            if(row.length >0){
              return row;
            }
        }
        return false;
    } catch (error) {
        throw error;
    }
}

async function getOtherDoc(dealId,userId){
    try {
        let checkDeal = checkDealId(dealId,userId);
        if (checkDeal) {
            let squery ="SELECT * FROM `ck_deal_documents`  WHERE  `deal_id` = ? AND status=1 AND document_type='deal_term' AND document_sub_type='other_document'";
            let row =   await query(squery,[dealId]);
            if(row.length >0){
              return row;
            }
        }
        return false;
    } catch (error) {
        throw error;
    }
}


async function updateTerm(termId,dealId,userId,minimum_investment,target,
    start_date,end_date,legal_name,founded,form,no_of_employees,website,facebook,linkedin,instagram,headquarters){
    try {
        let checkDeal = checkDealId(dealId,userId);
        if (checkDeal) {
            let squery =`UPDATE ck_deal_terms  SET minimum_investment=?,target = ?,
            start_date = ?,end_date =?,legal_name =?,founded =?,form =?,no_of_employees =?,website =?,facebook  =?,linkedin  =?,instagram  =?,headquarters =? WHERE id = ? AND deal_id = ?`;
           let row = await query(squery,[minimum_investment,target,
            start_date,end_date,legal_name,founded,form,no_of_employees,website,facebook,linkedin,instagram,headquarters,termId,dealId]);
          //console.log(squery);
            if(row['affectedRows']){
                return true;
            }
        }
        return false;
    } catch (error) {
        throw error;
    }
}


async function getImageName(dealId,userId,col_num){
    try {
        let checkDeal = checkDealId(dealId,userId);
        if (checkDeal) {
            let squery =`SELECT ${col_num} FROM ck_deals  WHERE  id = ?`;
           // console.log(squery)
            let row =   await query(squery,[dealId]);
            if(row.length >0){
           // console.log(row[0][col_num])
              return row[0][col_num];
            }
        }
        return '';
    } catch (error) {
        throw error;
    }
}

async function updateOrInserComCertDoc(dealId,file){
    try {
        let squery ="SELECT * FROM `ck_deal_documents` WHERE  `deal_id` = ? AND document_sub_type ='company_cert'";
        let row =   await query(squery,[dealId]);
        if(row.length >0){
           // return row[0];
           let squery ="UPDATE ck_deal_documents  SET document_name = ?, document_path = ? ,updated_at = ?  WHERE deal_id = ?";
           let row = await query(squery,[file,file, new Date(),dealId]);
          //console.log(squery);
            if(row['affectedRows']){
                return true;
            }
        }else{
            let squery ="INSERT INTO ck_deal_documents (deal_id,document_name,document_path,document_sub_type,document_type,created_at,updated_at) VALUES (?,?,?,?,?,?,?)";
            let row = await query(squery,[dealId,file,file,'company_cert','deal_term', new Date(), new Date()]);
           //console.log(squery);
             if(row['affectedRows']){
                 return true;
             }
        }
        return false;
    } catch (error) {
        throw error;
    }
}

async function updateOrInserComDueDil(dealId,file){
    try {
        let squery ="SELECT * FROM `ck_deal_documents` WHERE  `deal_id` = ? AND document_sub_type ='company_due_dilligence'";
        let row =   await query(squery,[dealId]);
        if(row.length >0){
           // return row[0];
           let squery ="UPDATE ck_deal_documents  SET document_name = ?, document_path = ? ,updated_at = ?  WHERE deal_id = ?";
           let row = await query(squery,[file,file, new Date(),dealId]);
          //console.log(squery);
            if(row['affectedRows']){
                return true;
            }
        }else{
            let squery ="INSERT INTO ck_deal_documents (deal_id,document_name,document_path,document_sub_type,document_type,created_at,updated_at) VALUES (?,?,?,?,?,?,?)";
            let row = await query(squery,[dealId,file,file,'company_due_dilligence','deal_term', new Date(), new Date()]);
           //console.log(squery);
             if(row['affectedRows']){
                 return true;
             }
        }
        return false;
    } catch (error) {
        throw error;
    }
}

async function updateOrInsertOtherDoc(dealId,file){
    try {
        let squery ="SELECT * FROM `ck_deal_documents` WHERE  `deal_id` = ? AND document_sub_type ='other_doc'";
        let row =   await query(squery,[dealId]);
        if(row.length >0){
           // return row[0];
           let squery ="UPDATE ck_deal_documents  SET document_name = ?, document_path = ? ,updated_at = ?  WHERE deal_id = ?";
           let row = await query(squery,[file,file, new Date(),dealId]);
          //console.log(squery);
            if(row['affectedRows']){
                return true;
            }
        }else{
            let squery ="INSERT INTO ck_deal_documents (deal_id,document_name,document_path,document_sub_type,document_type,created_at,updated_at) VALUES (?,?,?,?,?,?,?)";
            let row = await query(squery,[dealId,file,file,'other_doc','deal_term', new Date(), new Date()]);
           //console.log(squery);
             if(row['affectedRows']){
                 return true;
             }
        }
        return false;
    } catch (error) {
        throw error;
    }
}

async function getUserDealData(userId){
    try {
        // let checkDeal = checkDealId(dealId,userId);
        // if (checkDeal) {
            //will enable query later amdile module not enable for approve deal
          //  let squery =`SELECT id,deal_title,deal_description,deal_logo,deal_cover,deal_short_description,video_link FROM ck_deals  WHERE  user_id = ? AND status=3`;
         
          let squery =`SELECT id,deal_title,deal_description,deal_logo,deal_cover,deal_short_description,video_link FROM ck_deals  WHERE  user_id = ?`;
          // console.log(squery)
            let row =   await query(squery,[userId]);
            if(row.length >0){
           // console.log(row[0][col_num])
              return row;
            }
      //  }
        return false;
    } catch (error) {
        throw error;
    }
}


deal.updateTerm = updateTerm;
deal.getUserDealData=getUserDealData;
deal.updateOrInsertOtherDoc=updateOrInsertOtherDoc;
deal.updateOrInserComDueDil=updateOrInserComDueDil;
deal.updateOrInserComCertDoc=updateOrInserComCertDoc;
deal.getImageName =getImageName;
deal.getTerm =getTerm;
//Video
deal.deleteVideoTab = deleteVideoTab;
deal.getVideoTab = getVideoTab;
deal.insertVideoTab = insertVideoTab;

deal.deleteFaqTab = deleteFaqTab;
deal.getFaqTab = getFaqTab;
deal.insertFaqTab = insertFaqTab;

deal.deleteUpdatesTab = deleteUpdatesTab;
deal.getUpdatesTab = getUpdatesTab;
deal.insertUpdateTab = insertUpdateTab;
deal.updateBasicInfo = updateBasicInfo;
deal.getBasicInfo = getBasicInfo;
deal.updatePitchDoc = updatePitchDoc;
deal.getPitchDoc = getPitchDoc;
deal.insertRaiseCapital = insertRaiseCapital;
deal.getAllDealData = getAllDealData;
deal.getSingleDealData = getSingleDealData;
deal.getAllBestDealData = getAllBestDealData;
module.exports = deal;