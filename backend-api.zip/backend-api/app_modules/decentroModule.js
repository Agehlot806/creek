let decentro ={};

function verifyPanCard(userId,client_id, client_secret,module_secret, kyc_url,panNum) {
    //npm i xmlhttprequest

//  return {userId,client_id, client_secret,module_secret, panNum};
    var request = require('request');
    return new Promise((resolve, reject) => {        
            var options = {
            'method': 'POST',
            'url': kyc_url,
            'headers': {
                'client_id': client_id,
                'client_secret': client_secret,
                'module_secret': module_secret,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                "reference_id": userId,
                "document_type": "PAN",
                "id_number": panNum,
                "consent": "Y",
                "consent_purpose": "For bank account purpose only"
            })

            };
            request(options, function (error, response) {
              //  console.log(error)
            if (error) reject(error);
             resolve(response.body);
            }); 
    });
}

decentro.verifyPanCard = verifyPanCard;
module.exports = decentro;