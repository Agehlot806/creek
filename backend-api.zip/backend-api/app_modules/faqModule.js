let faq ={};

async function getCategory(catid){
    try {
        let squery ="SELECT category_name FROM ck_faq_categories WHERE id =?";
        let row =   await sqlcache(squery,[catid]);
        return row;
    } catch (error) {
        throw error;
    }
}


async function insertCategory(category_name){
    try{
        let sel_query ="SELECT count(category_name) cnt FROM ck_faq_categories WHERE category_name =?";
        let sel_row =   await sqlcache(sel_query,[category_name.trim()]);
      //  return sel_row;
        if(sel_row[0]['cnt'] == 0 || sel_row[0]['cnt'] ==''){
            let squery ="INSERT INTO ck_faq_categories (category_name,created_at,modified_at) VALUES (?,?,?)";
            let row = await query(squery,[category_name,new Date(),new Date()]);
            return row;
        }else{
            return {"err":"Record exist"};
        }
        
    }catch(err){
        throw err;
    }
}

async function getAllCategoryData(){
    try {
        let squery ="SELECT cfc.id,cfqa.category_id,cfc.category_name,cfqa.question,cfqa.answer FROM ck_faq_categories cfc LEFT JOIN ck_faq_question_answers cfqa on cfc.id = cfqa.category_id WHERE (cfc.status=1 AND cfqa.status =1)";
        let row=   await sqlcache(squery,[]);
       if(row.length > 0){
                         
            var step1 = row.reduce((result, {category_name, question, answer}) => {
                result[category_name] = result[category_name] || [];
                result[category_name].push({question, answer});
                return result;
            }, []);
           //return step1;
            var result = Object.keys(step1).map(category_name => ({category:category_name, questions: step1[category_name]}));
            return {"result":result};
        }
        return {"result":""};
    } catch (error) {
        throw error;
    }
}

faq.getCategory = getCategory;
faq.insertCategory = insertCategory;
faq.getAllCategoryData = getAllCategoryData;
module.exports = faq;