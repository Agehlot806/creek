let user = {};

async function checkUserEmailExists(email){
    try{
        let sel_query ="SELECT id,first_name,last_name,email_address,user_type FROM `ck_users` WHERE email_address =? AND status=1";
        let sel_row =   await query(sel_query,[email.trim()]);
      //  return sel_row;
        if(sel_row[0]){
            return sel_row[0];
        }else{
            return false;
        }
        
    }catch(err){
        throw err;
    }
}

async function checkUserEmailExists(email){
    try{
        let sel_query ="SELECT id,first_name,last_name,email_address,user_type FROM `ck_users` WHERE email_address =? AND status=1";
        let sel_row =   await query(sel_query,[email.trim()]);
      //  return sel_row;
        if(sel_row[0]){
            return sel_row[0];
        }else{
            return false;
        }
        
    }catch(err){
        throw err;
    }
}


async function getUserDetails(userId){
    try{
        let sel_query ="SELECT id,first_name,last_name,email_address email,mobile_number contactNumber,user_type,address_line1 address1,address_line2 address2,country,state,zipcode postalCode FROM `ck_users` WHERE id =? AND status=1";
        let sel_row =   await query(sel_query,[userId.trim()]);
      //  return sel_row;
        if(sel_row[0]){
            return sel_row[0];
        }else{
            return false;
        }
        
    }catch(err){
        throw err;
    }
}

async function registerUserGoogle(fullName,email){
    try{
        var firstName = fullName.split(' ').slice(0, -1).join(' ');
        var lastName = fullName.split(' ').slice(-1).join(' ');
        let squery ="INSERT INTO ck_users (id,first_name,last_name,email_address,status) VALUES (UUID(),?,?,?,1)";
        let row = await query(squery,[firstName,lastName,email]);
      //  console.log(row);
        return row;
        
    }catch(err){
        throw err;
    }
}


function getUserDetailsOTPLess(clientid, client_secret, url, token, state) {
    //npm i xmlhttprequest
    var request = require('request');
    return new Promise((resolve, reject) => {        
            var options = {
            'method': 'POST',
            'url': url,
            'headers': {
                'appId': clientid,
                'appSecret': client_secret,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                "token": token,
                "state": state
            })

            };
            request(options, function (error, response) {
            if (error) reject(error);
             resolve(response.body);
            }); 
    });
}
   
async function checkMobileExist(mobile){
    try{
        let sel_query ="SELECT id,first_name,last_name,email_address,mobile_number,user_type FROM `ck_users` WHERE mobile_number =? AND status=1";
        let sel_row =   await query(sel_query,[mobile.trim()]);
      //  return sel_row;
        if(sel_row[0]){
            return sel_row[0];
        }else{
            return false;
        }
        
    }catch(err){
        throw err;
    }
}

async function registerUserOTPLess(firstName,lastName,mobile){
    try{
        let squery ="INSERT INTO ck_users (id,first_name,last_name,mobile_number,status) VALUES (UUID(),?,?,?,1)";
        let row = await query(squery,[firstName,lastName,mobile]);
      //  console.log(row);
        return row;
        
    }catch(err){
        throw err;
    }
}

async function updateUserProfileById(userId,first_name,last_name,email_address,mobile_number,address_line1,address_line2,country,state,zipcode){
    try{
        //console.log(userId);
        let squery ="UPDATE ck_users  SET first_name = ? ,last_name = ? ,email_address =?, mobile_number= ?, address_line1 = ? , address_line2 = ?, country= ?, state= ?, zipcode= ? WHERE id = ? AND status=1";
        let row = await query(squery,[first_name,last_name,email_address,mobile_number,address_line1,address_line2,country,state,zipcode,userId]);
       //console.log(squery);
      
        return row;
        
    }catch(err){
        console.log(err)
        throw err;
    }
}

async function checkUserIdExists(userId){
    try{
        let sel_query ="SELECT id,first_name,last_name,email_address,user_type FROM `ck_users` WHERE id =? AND status=1";
        let sel_row =   await query(sel_query,[userId.trim()]);
      //  return sel_row;
        if(sel_row[0]){
            return sel_row[0];
        }else{
            return false;
        }
        
    }catch(err){
        throw err;
    }
}

async function insertUserHistory(user,platform_id,ipaddress,login_status,token){
    try{
        let squery ="INSERT INTO ck_user_devices (user_id,platform_id,ipaddress,login_status,token) VALUES (?,?,?,?,?)";
        let row = await query(squery,[user,platform_id,ipaddress,login_status,token]);
        // console.log(row);
        return row;
        
    }catch(err){
        throw err;
    }
}


user.insertUserHistory=insertUserHistory;

user.checkUserIdExists =checkUserIdExists;
user.updateUserProfileById =updateUserProfileById;
user.registerUserOTPLess =registerUserOTPLess;
user.getUserDetailsOTPLess =getUserDetailsOTPLess;
user.checkMobileExist =checkMobileExist;
user.checkUserEmailExists =checkUserEmailExists;
user.registerUserGoogle =registerUserGoogle;
user.getUserDetails =getUserDetails;
module.exports =user;
