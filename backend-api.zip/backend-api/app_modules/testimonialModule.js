let testimonial ={};


async function getAllTestimonialData(){
    try {
        let squery ="SELECT title,description,img FROM ck_testimonial WHERE status =1";
        let row=   await sqlcache(squery,[]);

       if(row.length > 0){
                             
           
            return {"result":row};
        }
        return {"result":""};
    } catch (error) {
        throw error;
    }
}

testimonial.getAllTestimonialData = getAllTestimonialData;
module.exports = testimonial;