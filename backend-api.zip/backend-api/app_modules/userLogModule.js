let logUser = {}

async function trackUserActivity(nosql,email_address,username,user_type=" ",module_record_id=" ",module_name=" ",remarks=" ",module_action=" ",old_record_value=" ",new_record_value=" "){
try{
 // console.log(nosql)
    let Log =   nosql.model('Log');
   // console.log(Log)
    let entry = new Log({
      email_address:email_address,
      username:username,
      user_type:user_type,
      module_record_id:module_record_id,
      module_name:module_name,
      remarks:remarks,
      module_action:module_action,
      old_record_value:old_record_value,
      new_record_value:new_record_value
    });
  return  entry.save();
}catch(err){
    console.log(err);
    throw(err)
}
 
}

logUser.trackUserActivity = trackUserActivity;
module.exports = logUser