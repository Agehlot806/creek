const pool = require('../config/mysql.config')

module.exports = {
  panVerification: async(data,callBack)=>{
    try{
      console.log(":L:L:L:L");
         pool.query(
            `insert into Ck_user_pan_kyc(kycStatus,status,message,kycResultIdNumber,kycResultIdStatus,kycResultName,responseCode,requestTimestamp,responseTimestamp,decentroTxnId)
            values(?,?,?,?,?,?,?,?,?,?)`,[
              data.kycStatus,
              data.status,
              data.message,
              data.kycResult.idNumber,
              data.kycResult.idStatus,
              data.kycResult.name,
              data.responseCode,
              data.requestTimestamp,
              data.responseTimestamp,
              data.decentroTxnId,
    ],
            (error, results) => {
              console.log("_+" + "_+_+_+_+_+_+_+_jjjjjjj15jjjjjjjjjjjj", results);
              if (error) {
                console.log("___________________", error);
                return callBack(error);
              }
              console.log("_+_+_+_+_+_+_+_+_", results);
              return callBack(null, results);

            },
            )

    }catch(err){
        return err;
    }
  }
}