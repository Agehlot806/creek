const router = require('express').Router();
const decentroObj = require('../app_modules/decentroModule');
router.post('/verifypan', async (req, res, next) => {
  //  console.log(query);
  try {
    let userId = req.session.user.id;
    // return res.status(200).json({ "uid":userId,
    // "cid": process.env.DECENTRO_CLIENT_ID,
    //   "pan": panNum});
      // if(userId =='' || userId ==NULL){
      //   return res.status(400).json({"err":"Login required"});
      // }
      //return res.status(400).json({"err":"Login required"});
       const {panNum} = req.body;

       //return res.status(200).json(panNum);
      let results =  await  decentroObj.verifyPanCard(
        userId,
      process.env.DECENTRO_CLIENT_ID,
      process.env.DECENTRO_CLIENT_SECRET,
      process.env.DECENTRO_MODULE_KYC_SECRET,
      process.env.DECENTRO_KYC_URL,
      panNum);
        return res.status(200).json(results);
    } catch (error) {
      next(error);
    }
});

router.get('/', async (req, res, next) => {
  //  console.log(query);
  try {
       
        return res.status(200).json({"err":"No record found!"});
     
    } catch (error) {
      next(error);
    }
});

module.exports = router;