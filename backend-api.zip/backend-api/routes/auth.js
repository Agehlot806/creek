const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const { OAuth2Client } = require('google-auth-library');
const client = new OAuth2Client(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  /**
   * To get access_token and refresh_token in server side,
   * the data for redirect_uri should be postmessage.
   * postmessage is magic value for redirect_uri to get credentials without actual redirect uri.
   */
  'postmessage'
);
const {registerValidation, loginValidation} = require('../validations.js');
const user = require('../app_modules/userAuth');
const { json } = require('body-parser');

// Routers

// router.post('/otplogin', async (req, res,next) => {
//   try{
//     const { token,state,fname,lname }  = req.body;
//     return res.json({ msg: " Logged In Successfully"});
   
//   }catch(err){
//     //
//    //res.json({ msg: " Logged In Unsuccessfully"});
//    next(err);
//   }
 
// });

router.post('/login', async (req, res) => {
  try{
    const { token }  = req.body
    const r = await client.getToken(token);
    const idToken = r.tokens.id_token;
    const ticket = await client.verifyIdToken({
        idToken: idToken,
        audience: process.env.GOOGLE_CLIENT_ID
    });
     const { name, email, picture } = ticket.getPayload();
      // Validation check
    //  const {error} = loginValidation(req.body);
      //if(error) return res.status(400).send(error.details[0].message);
  
      // Email existance check
     let registeredUser = await user.checkUserEmailExists(email);
      // const registeredUser = await user.checkUserEmailExists(email);
      if(registeredUser.email_address != email){
        //const { name, email, picture } = ticket.getPayload(); 
        const results =  await user.registerUserGoogle(name,email);
       //return  res.json({ msg: " Logged In Successfully", results});
        if(results.affectedRows){
           registeredUser = await user.checkUserEmailExists(email);
         //  return  res.status(200).json({"result":"Rows inserted successfuly",registeredUser,e:req.body.email});  
           //console.log(registeredUser);
           if (registeredUser.length === 0) return  res.status(200).json({"result":"User status disabled"});
         }
      } 
      var hour = 3600000
      req.session.cookie.expires = new Date(Date.now() + hour);
      req.session.cookie.maxAge = hour;
      req.session.user = registeredUser;
      let role;
      if (registeredUser.user_type===1) {
          role = 'startup';
      } else if (registeredUser.user_type===2) {
        role = 'investor';
      }
      registeredUser.role= role;
      //console.log(acl)
       acl.addUserRoles(registeredUser.id, role)
    //  return res.json(registeredUser.id);
      // Create and assign JWT
      // const token = jwt.sign({id: registeredUser.id}, process.env.JWT_SECRET,
      //     {
      //       expiresIn:  process.env.JWT_EXPIRE_TIME,
      //     });
      // res.header('auth-token', token).send(token);
      let platform_id = req.get('User-Agent');
      var ip = req.headers['x-forwarded-for'] ||  req.connection.remoteAddress;
      let sid = req.sessionID;
      let login_status = true;
      let user_details_log = registeredUser.id;
     let log =  user.insertUserHistory(user_details_log,platform_id,ip,login_status,sid);
    return  res.json({ msg: " Logged In Successfully", registeredUser});

   }catch(err){
    //
   //res.json({ msg: " Logged In Unsuccessfully"});
   next(err);
  }
 
})
router.get('/logout', async (req, res) => {
  req.session.destroy(err => {
      if (err) {
          return res.json({ error: 'Logout error' })
      }
      req.session = null
      res.clearCookie('creek', {path: '/'})
      return res.json({ 'clearSession': 'Logout success' })
  })
});


router.get('/getuserdetails', async (req, res,next) => {
  try{
    let userId = req.session.user.id;
    //return res.json(userId)
    //console.log(userId);
    if(!userId){
      return res.json("user not found")
    }
    if (userId) {
    
      let userDetails = await user.getUserDetails(userId);
      return res.json(userDetails);
    }else{
      return res.status(400).json({ 'err': 'You are not allowed to access this api!' })
    }
    
  }catch(err){
    
   //res.json({ msg: " Logged In Unsuccessfully"});
   next(err);
  }
});


router.post('/update', async (req, res,next) => {
  try{
    let userId = req.session.user.id;
    const { first_name,last_name,email_address,mobile_number,address_line1,address_line2,country,state,zipcode }  = req.body;
   //return res.json(req.body)
    //console.log(userId);
    if (userId) {
      let userDetails = await user.checkUserIdExists(userId);
      //return res.json(userDetails)
      if(userDetails.email_address || userDetails.mobile_number){
       // return res.json(userDetails)
        let updateUser = await user.updateUserProfileById(userId,first_name,last_name,email_address,mobile_number,address_line1,address_line2,country,state,zipcode);
        if(updateUser.changedRows){
          return res.json(true);
        }
         return res.json(false);
      }
      return res.json({"err":"User not found"});
    }else{
      return res.status(400).json({ 'err': 'You are not allowed to access this api!' })
    }
    
  }catch(err){
    //
   //res.json({ msg: " Logged In Unsuccessfully"});
   next(err);
  }
});


router.post('/otplogin', async (req, res,next) => {
  try {
    const { token,state,fname,lname }  = req.body;
   // return res.json({"a":process.env.OTPLESS_CLIENT_ID,"e": process.env.OTPLESS_CLIENT_SECRET,"b": process.env.OTPLESS_REQUEST_URL, "c":token, "d":state});
    let getResFromOtpLess = await user.getUserDetailsOTPLess(process.env.OTPLESS_CLIENT_ID, process.env.OTPLESS_CLIENT_SECRET, process.env.OTPLESS_REQUEST_URL, token, state);
    
    if (getResFromOtpLess.responseCode == 200) {
      let userObjData = getResFromOtpLess.data;
      let mobile = userObjData.mobile;
      let mobileExist = await user.checkMobileExist(mobile);
      
      if (mobileExist.mobile_number != mobile) {
        const results =  await user.registerUserOTPLess(fname,lname,mobile);
        //return  res.json({ msg: " Logged In Successfully", results});
         if(results.affectedRows){
            let registeredUser = await user.checkMobileExist(mobile);
          //  return  res.status(200).json({"result":"Rows inserted successfuly",registeredUser,e:req.body.email});  
            //console.log(registeredUser);
            if (registeredUser.length === 0) return  res.status(200).json({"result":"User status disabled"});
          }
      }
      var hour = 3600000
      req.session.cookie.expires = new Date(Date.now() + hour);
      req.session.cookie.maxAge = hour;
      req.session.user = mobileExist;
      let role;
      if (mobileExist.user_type===1) {
          role = 'startup';
      } else if (mobileExist.user_type===2) {
        role = 'investor';
      }
      mobileExist.role= role;
      //console.log(acl)
       acl.addUserRoles(mobileExist.id, role)
      // return res.json(registeredUser.id);
      // Create and assign JWT
      // const token = jwt.sign({id: registeredUser.id}, process.env.JWT_SECRET,
      //     {
      //       expiresIn:  process.env.JWT_EXPIRE_TIME,
      //     });
      // res.header('auth-token', token).send(token);
      let platform_id = req.get('User-Agent');
      var ip = req.headers['x-forwarded-for'] ||  req.connection.remoteAddress;
      let sid = req.sessionID;
      let login_status = true;
      let user_details_log = mobileExist.id;
     let log =  user.insertUserHistory(user_details_log,platform_id,ip,login_status,sid);
     return res.json({ msg: " Logged In Successfully", mobileExist});
    }else{
      return res.json(getResFromOtpLess);
    }

    
   
  }catch(err){
    //
   //res.json({ msg: " Logged In Unsuccessfully"});
   next(err);
  }
 
});



//////////////////////////////////////////////


router.post('/dlogin', async (req, res,next) => {
  try{
    const { email }  = req.body;

  //  // return res.status(200).send(token);
  //   const r = await client.getToken(token);
  //   //return res.status(200).send(r);
  //   const idToken = r.tokens.id_token;
  //   //return res.status(200).send(idToken);

  //   // 4/0AfgeXvsAJW12ZKcHKAdLTjeyK3dyJWfR6TXtnp3qMFUgWtD5lpZ16K8yL8R2HzVxZNjP0g
  //   const ticket = await client.verifyIdToken({
  //       idToken: idToken,
  //       audience: process.env.GOOGLE_CLIENT_ID
  //   });
  //    const { name, email, picture } = ticket.getPayload();
      //Validation check
   //  const {error} = loginValidation(req.body);
     // if(error) return res.status(400).send(error.details[0].message);
  
      // Email existance check
     let registeredUser = await user.checkUserEmailExists(email);
    // return res.json(registeredUser);
      // const registeredUser = await user.checkUserEmailExists(email);
      if(registeredUser.email_address != email){
        //const { name, email, picture } = ticket.getPayload(); 
        const results =  await user.registerUserGoogle(name,email);
       //return  res.json({ msg: " Logged In Successfully", results});
        if(results.affectedRows){
           registeredUser = await user.checkUserEmailExists(email);
         //  return  res.status(200).json({"result":"Rows inserted successfuly",registeredUser,e:req.body.email});  
           //console.log(registeredUser);
           if (registeredUser.length === 0) return  res.status(200).json({"result":"User status disabled"});
         }
      } 
      var hour = 3600000
      req.session.cookie.expires = new Date(Date.now() + hour);
      req.session.cookie.maxAge = hour;
      req.session.user = registeredUser;
      let role;
      if (registeredUser.user_type===1) {
          role = 'startup';
      } else if (registeredUser.user_type===2) {
        role = 'investor';
      }
      registeredUser.role= role;
      //console.log(acl)
       acl.addUserRoles(registeredUser.id, role)
      // return res.json(registeredUser.id);
      // Create and assign JWT
      // const token = jwt.sign({id: registeredUser.id}, process.env.JWT_SECRET,
      //     {
      //       expiresIn:  process.env.JWT_EXPIRE_TIME,
      //     });
      // res.header('auth-token', token).send(token);
     return res.json({ msg: " Logged In Successfully", registeredUser});
  }catch(err){
    //
   //res.json({ msg: " Logged In Unsuccessfully"});
   next(err);
  }
 
});


//////////////////////////////////////////////



module.exports = router
