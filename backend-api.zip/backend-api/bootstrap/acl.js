

// var settings = function(){
//     console.log("acl",acl)
//     acl.allow(rules);
// }
let nonLoginUrl = ['/api/auth/login','/api/faq'];
// var authCheck = function(req,res, next){
//     if (req.session.user) {
//         let userId = req.session.user.id;
//         let methodType = req.method;
//         let resources = req._parsedUrl.pathname.replace(/[0-9]+/g,':id');
//         acl.isAllowed(userId, resources, methodType, function(err, agree){
//             if (err) {
//               return  res.status(500).json({err:"not allowed"});
//             } else {
//                 if(agree){
//                     next();
//                 }else{
//                     return res.status(403).json({err:"not allowed"});
//                 }
//             }
//         })
//     } else {
//         let resources = req._parsedUrl.pathname.split('/');
//         if(req.url === '/' || req.url === '/api/faq'){
//             next();
//         }else{
//             return res.status(403).json({err:"not allowed"});
//         }
//     }

// }

module.exports = function(obj){
    var acl=obj;
 //   console.log("acl",acl);

let rules = [
    {
        roles:['startup'],
        allows:[   
            {
                resources:['/api/user/getuserdetails','/api/deal/alldeals',
                '/api/deal/bestdeals','/api/user/update','/api/faq',
                '/api/testimonial','/api/faq/insert-cat',
                '/api/user/logout','/api/decentro/verifypan'
                ,'/api/deal/createraisecapital',
                '/api/deal/updatepitch',
                '/api/deal/getpitch/:id',
                '/api/deal/getbasicinfo/:id',
                '/api/deal/updatebasicinfo',
                '/api/deal/insertupdatetab',
                '/api/deal/getupdatestab/:id',
                '/api/deal/deleteupdatetab',
                '/api/deal/insertfaqtab',
                '/api/deal/getfaqtab/:id',
                '/api/deal/deletefaqtab',
                '/api/deal/insertvideotab',
                '/api/deal/getvideotab/:id',
                '/api/deal/deletevideotab',
                '/api/deal/getterm/:id',
                '/api/deal/uploadcompanycert',
                '/api/deal/alldealsuser',
                '/api/deal/updateterm',
            ], 
            permissions:['get', 'post','put', 'delete']
            }
        ]
    },
    {
        roles:['investor'],
        allows:[
            {
                resources:['/api/user/getuserdetails','/api/deal/alldeals',
                '/api/deal/bestdeals','/api/user/update','/api/faq','/api/testimonial',
                '/api/faq/insert-cat','/api/user/logout','/api/decentro/verifypan'
                ,'/api/deal/createraisecapital',
                '/api/deal/updatepitch',
                '/api/deal/getpitch/:id',
                '/api/deal/getbasicinfo/:id',
                '/api/deal/updatebasicinfo',
                '/api/deal/insertupdatetab',
                '/api/deal/getupdatestab/:id',
                '/api/deal/deleteupdatetab',
                '/api/deal/insertfaqtab',
                '/api/deal/getfaqtab/:id',
                '/api/deal/deletefaqtab',
                '/api/deal/insertvideotab',
                '/api/deal/getvideotab/:id',
                '/api/deal/deletevideotab',
                '/api/deal/getterm/:id',
                '/api/deal/uploadcompanycert',
                '/api/deal/alldealsuser',
                '/api/deal/updateterm',
                ], 
                permissions:['GET', 'POST','PUT', 'DELETE']
            }
        ]
    }
];
    return {
        setting:function(){
          //  console.log("acl",acl)
            acl.allow(rules);
        },
        authCheck:function(req,res, next){
            if (req.session.user) {
                let userId = req.session.user.id;
                let methodType = req.method;
                let resources = req._parsedUrl.pathname.replace(/[0-9]+/g,':id');
                acl.isAllowed(userId, resources, methodType, function(err, agree){
                    if (err) {
                      return  res.status(500).json({err:"not allowed"});
                    } else {
                       console.log(agree)
                        if(agree){
                            next();
                        }else{
                            return res.status(403).json({err:`not allowed ${userId} ${req.url}`});
                        }
                    }
                })
            } else {
                let resources = req._parsedUrl.pathname.split('/');
                let resources_param = req._parsedUrl.pathname.replace(/[0-9]+/g,':id');
                //console.log(resources_param)
                if(req.url === '/' || req.url === '/api/user/dlogin' || req.url === '/api/faq' || resources_param === '/api/deal/bestdeals' || resources_param == '/api/user/otplogin' || resources_param === '/api/deal/alldeals/:id' || req.url === '/api/testimonial' || req.url === '/api/deal/alldeals' || req.url === '/api/user/login' || req.url === '/api/user/logout'){
                    next();
                }else{
                    return res.status(403).json({err:`not allowed ${req.url}`});
                }
            }
        
        }
    };
}