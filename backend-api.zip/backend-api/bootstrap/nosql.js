// getting-started.js
const mongoose = require('mongoose');

main().then(()=> console.log("mongo connected!")).catch(err => console.log(err));

async function main() {
  console.log(process.env.DB_URL);
  await mongoose.connect(process.env.DB_URL);
  
  // use `await mongoose.connect('mongodb://user:password@localhost:27017/test');` if your database has auth enabled
}