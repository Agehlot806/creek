const Memcached = require('memcached');
function queryCache(sqlquery,params,callback,total_time_limit){
   // console.log(db);
    let hashstr = require('md5')(sqlquery+JSON.stringify(params));
    if(total_time_limit ==undefined){
        total_time_limit = 1000;
    }

  
    var memcached = new Memcached(process.env.MEMCACHED_URL, {});
         return new Promise(function(resolve,reject){
            memcached.get(hashstr, function (err, data) {
                if(err){
                    reject(err)
                }
               // console.log(err, data);
                if(data != undefined && data !='') {
               //  console.log("cache",data);
                    resolve(JSON.parse(data));
                } else {
                    dbcon.getConnection(function(err, connection) {
                        if (err){
                            reject(err);
                        }else{
                            // Use the connection
                            connection.query(sqlquery,params, function(err,rows){
                                if(err){
                                    reject(err);
                                }else{
                                  //  console.warn(hashstr,JSON.stringify(rows),total_time_limit)
                                //  res.json(rows);
                                memcached.set(hashstr,JSON.stringify(rows),total_time_limit,
                                function (err) { 
                                    if(err){
                                        reject(err)
                                    }
                                    
                                });
                                    resolve(rows);
                                }
                            });
                            //connection.release();
                        }
                    });
                }
            });
         });
}   


module.exports = function (dbpool){  
    dbcon = dbpool;  
    return queryCache;
}
